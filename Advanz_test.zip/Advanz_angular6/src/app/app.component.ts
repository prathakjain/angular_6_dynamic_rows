import { Component } from '@angular/core';
import { QuestionService } from './question.service';
import { Question } from './question';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'advance101';
  message:any = '';
  typedata : any[];

  public questionArray:any = [];
  constructor( private questionservice: QuestionService ){  


    this.questionservice.getType().subscribe(
        data  => {
            this.typedata = data['data'],
            console.log(data['data']);
        },
        error => this.typedata = error
    )

  }
    AddQuestion(){
         this.questionArray.push({'question':'', 'type':''})
    }
 
    clear(){
        this.questionArray= [];
    }

     getCity(id, index){
         this.questionArray[index].answer = [];
         if(id == 1){
             this.questionArray[index].answer.push({'answertext':'', 'addsubquestion':index, 'anotherquestion': []})
         }
         else if(id == 3){
             this.questionArray[index].answer.push({'answertext':'', 'addsubquestion':index, 'anotherquestion': []})
         }
         else{
             this.questionArray[index].answer.push({'answertext':'', 'addsubquestion':index, 'anotherquestion': []}, {'answertext':'', 'addsubquestion':index, 'anotherquestion': []}, {'answertext':'', 'addsubquestion':index, 'anotherquestion': []}, {'answertext':'', 'addsubquestion':index, 'anotherquestion': []}, {'answertext':'', 'addsubquestion':index, 'anotherquestion': []})
         }
         
     }

     addSub(item, i){
       console.log(item, i);
       if(i == 0){
        item.anotherquestion = [];
       }
      item.anotherquestion.push({'question':'', 'type':'1', 'answer': []})
      console.log(this.questionArray)
     }

     getInside(id, item, index){
       console.log(item, id);
      item.answer = [];
      if(id == 1){
          item.answer.push({"answertext":"",
				"addsubquestion":0,
				"anotherquestion": []})
      }
      else if(id == 3){
          item.answer.push({"answertext":"",
				"addsubquestion":0,
				"anotherquestion": []})
      }
      else{
          item.answer.push({"answertext":"",
				"addsubquestion":0,
				"anotherquestion": []}, {"answertext":"",
				"addsubquestion":0,
				"anotherquestion": []}, {"answertext":"",
				"addsubquestion":0,
				"anotherquestion": []}, {"answertext":"",
				"addsubquestion":0,
				"anotherquestion": []}, {"answertext":"",
				"addsubquestion":0,
				"anotherquestion": []})
      }
      
  }


 
     submitForm(){
        this.questionservice.createQuestions(this.questionArray).subscribe(
            data => console.log(data),
            error => this.message = error
        );

        //console.log(this.questionArray);
     }
}
