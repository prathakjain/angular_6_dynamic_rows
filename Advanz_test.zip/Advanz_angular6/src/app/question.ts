export class Question {
    question: any;
    type: any;
    answer: any[];
}