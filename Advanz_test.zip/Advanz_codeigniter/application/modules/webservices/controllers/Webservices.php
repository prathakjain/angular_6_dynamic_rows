<?php
defined('BASEPATH') OR exit('No direct script access allowed');
//require APPPATH . '/libraries/REST_Controller.php';


class Webservices extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	public function __construct() {
		header('Access-Control-Allow-Origin: *');
   		header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
		header('Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept');

		parent::__construct();
		$this->load->model('call_model');
	}

	public function index(){ 
		$this->load->view('welcome_message');
	}

	public function gettype(){
		$arg = array();    
		$record = $this->call_model->getdatafromtable('test_answer_choice');
		if(!empty($record)){
	  		$arg['status'] = 1;
			$arg['data']  = $record;
		} else {
			$arg['status'] = 0;
			$arg['message']  = "Successfully";
		}
		echo json_encode($arg);
		
	}

	public function addcall(){
		$arg = array();        
    	$data = $_POST = json_decode(file_get_contents("php://input"), true);
    	if(!empty($data)){
        	foreach ($data as $key => $value) {
        		$q = $value['question'];
        		$t = $value['type'];
        		if($t == 1 || $t == 3){
        			$insertdata = array(
        				'question' => $q,
						'question_type' => $t,
						'parent_answer_id' => 0,
        			);
        			$question_id = $this->call_model->insertdata('test_question', $insertdata);

        			if($question_id){
        				$ans = $value['answer'][0]['answertext'];
        				$ansinsertdata = array(
	        				'question_id' => $question_id,
							'answer' => $ans,
	        			);
	        			$ans_id = $this->call_model->insertdata('test_answer', $ansinsertdata);
        			}
        			//call instert function and get insert_id
        			$addsubquestion = $value['answer'][0]['addsubquestion'];
        			if($addsubquestion == 1 && !empty($value['answer'][0]['anotherquestion'])){

        				$inserted_id = $ans_id;
        				$this->recursivedata($value['answer'][0]['anotherquestion'],$inserted_id);
        			}
        		} else {
        			$insertdata = array(
        				'question' => $q,
						'question_type' => $t,
						'parent_answer_id' => 0,
        			);
        			$question_id = $this->call_model->insertdata('test_question', $insertdata);

        			foreach ($value['answer'] as $ans_value) {
	        			if($question_id){
	        				$ans = $ans_value['answertext'];
	        				$ansinsertdata = array(
		        				'question_id' => $question_id,
								'answer' => $ans,
		        			);
		        			$ans_id = $this->call_model->insertdata('test_answer', $ansinsertdata);
	        			}
	        			//call instert function and get insert_id
	        			$addsubquestion = $ans_value['addsubquestion'];
	        			if($addsubquestion == 1){
	        				$inserted_id = $ans_id;
	        				$this->recursivedata($ans_value['anotherquestion'],$inserted_id);
	        			}
        			}
        		}
        	}
        	
        	$arg['status'] = 1;
			$arg['message']  = "Successfully";

        } else {
        	$arg['status'] = 0;
			$arg['message']  = "Please Send Valid Data";
        }

		echo json_encode($arg);
	}


	/*public function test_post(){
		$arg = array();    
		$arg['status'] = 1;
		$arg['message']  = "Successfully";    
		echo json_encode($arg);
	}


	public function addblog_post(){
	$arg = array();        
    	$data = $_POST = json_decode(file_get_contents("php://input"), true);

    	print_r($_POST);
        if($_POST) { 
        	$arg = $_POST;
        }
        //echo json_encode($arg);
        if(!empty($data)){
        	foreach ($data as $key => $value) {
        		$q = $value['question'];
        		$t = $value['type'];
        		if($t == 1 || $t == 3){
        			$ans = $value['answer'][0]['answertext'];
        			//call instert function and get insert_id
        			$addsubquestion = $value['answer'][0]['addsubquestion'];
        			if($addsubquestion == 1){
        				//anotherquestion

        				$this->recursivedata($value['answer'][0]['anotherquestion'],$inserted_id);
        			}
        		}else{
        			foreach ($value['answer'] as $ans_value) {
        				$ans = $ans_value['answertext'];
	        			//call instert function and get insert_id
	        			$addsubquestion = $ans_value['addsubquestion'];
	        			if($addsubquestion == 1){
	        				//anotherquestion
	        				//$this->recursivedata($ans_value['anotherquestion'],$inserted_id);
	        			}
        			}
        		}
        	}
        }
	}*/

	public function recursivedata($data,$inserted_id){

		foreach($data as $key => $value){

			$q = $value['question'];
    		$t = $value['type'];
    		if($t == 1 || $t == 3){
    			$insertdata = array(
    				'question' => $q,
					'question_type' => $t,
					'parent_answer_id' => $inserted_id,
    			);
    			$question_id = $this->call_model->insertdata('test_question', $insertdata);

    			if($question_id){
    				$ans = $value['answer'][0]['answertext'];
    				$ansinsertdata = array(
        				'question_id' => $question_id,
						'answer' => $ans,
        			);
        			$ans_id = $this->call_model->insertdata('test_answer', $ansinsertdata);
    			}
    			//call instert function and get insert_id
    			$addsubquestion = $value['answer'][0]['addsubquestion'];
    			if($addsubquestion == 1 && !empty($value['answer'][0]['anotherquestion'])){
    				//anotherquestion
    				$inserted_id = $ans_id;
    				$this->recursivedata($value['answer'][0]['anotherquestion'],$inserted_id);
    			}
    		}else{
    			$insertdata = array(
    				'question' => $q,
					'question_type' => $t,
					'parent_answer_id' => 0,
    			);
    			$question_id = $this->call_model->insertdata('test_question', $insertdata);
    			foreach ($value['answer'] as $ans_value) {
        			if($question_id){
        				$ans = $ans_value['answertext'];
        				$ansinsertdata = array(
	        				'question_id' => $question_id,
							'answer' => $ans,
	        			);
	        			$ans_id = $this->call_model->insertdata('test_answer', $ansinsertdata);
        			}
        			//call instert function and get insert_id
        			$addsubquestion = $ans_value['addsubquestion'];
        			if($addsubquestion == 1){
        				$inserted_id = $ans_id;
        				$this->recursivedata($ans_value['anotherquestion'],$inserted_id);
        			}
    			}	
    		}

        }
	}




}
