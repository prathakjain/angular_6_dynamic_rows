<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Call_model extends CI_Model {
	public function __construct(){
		parent::__construct();
	}

	public function insertdata($tbnm = null, $var = array()) {
		$this->db->insert($tbnm, $var);
		return $this->db->insert_id(); 
	}


	public function getdatafromtable($tbnm, $condition = array(), $data = "*", $limit="", $offset="", $orderby ='')
	{
		$this->db->select($data);
		$this->db->from($tbnm);
		if(!empty($condition)){
			$this->db->where($condition);
		}
        $this->db->order_by("$orderby", "DESC");
		If($limit != '')
		{
			$this->db->limit($limit, $offset);
		}

		$query = $this->db->get();
		if ($query->num_rows() > 0) {
			return $query->result_array();
		} else {
			return false;
		}
	}


}