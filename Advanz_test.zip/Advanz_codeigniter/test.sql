-- phpMyAdmin SQL Dump
-- version 4.6.6deb5
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jan 18, 2019 at 02:47 PM
-- Server version: 5.7.24-0ubuntu0.18.04.1
-- PHP Version: 7.2.10-0ubuntu0.18.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test`
--

-- --------------------------------------------------------

--
-- Table structure for table `test_answer`
--

CREATE TABLE `test_answer` (
  `id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `answer` longtext NOT NULL,
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `test_answer_choice`
--

CREATE TABLE `test_answer_choice` (
  `choice_id` int(11) NOT NULL,
  `choice_name` varchar(255) NOT NULL,
  `subquestion_allowed` tinyint(1) NOT NULL,
  `status` enum('0','1') NOT NULL COMMENT 'show on Frontend 0 = false, 1 = true',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `test_answer_choice`
--

INSERT INTO `test_answer_choice` (`choice_id`, `choice_name`, `subquestion_allowed`, `status`, `created_on`) VALUES
(1, 'Single Text', 1, '1', '2019-01-16 11:53:40'),
(2, 'Multipal Text', 1, '1', '2019-01-16 11:53:40'),
(3, 'Multiline Text', 0, '1', '2019-01-16 11:54:01');

-- --------------------------------------------------------

--
-- Table structure for table `test_question`
--

CREATE TABLE `test_question` (
  `id` int(11) NOT NULL,
  `question` mediumtext NOT NULL,
  `question_type` int(1) DEFAULT NULL COMMENT 'From answer choice table',
  `parent_answer_id` int(11) NOT NULL DEFAULT '0' COMMENT '0 = Parent, id = answer Question',
  `created_on` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `test_answer`
--
ALTER TABLE `test_answer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `test_answer_choice`
--
ALTER TABLE `test_answer_choice`
  ADD PRIMARY KEY (`choice_id`);

--
-- Indexes for table `test_question`
--
ALTER TABLE `test_question`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `test_answer`
--
ALTER TABLE `test_answer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `test_answer_choice`
--
ALTER TABLE `test_answer_choice`
  MODIFY `choice_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `test_question`
--
ALTER TABLE `test_question`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
